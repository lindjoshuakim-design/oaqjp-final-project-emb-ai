import requests
import json

def emotion_detector(text_to_analyze):
    """
    Analyzes text emotions using the Watson NLP API and returns a formatted dictionary.
    """
    url = 'https://skills.network'
    headers = {"grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"}
    input_json = { "raw_document": { "text": text_to_analyze } }
    
    try:
        response = requests.post(url, json=input_json, headers=headers)
        
        # Handle blank/invalid input per assignment requirements (HTTP 400 or 500)
        if response.status_code in:
            return {
                'anger': None,
                'disgust': None,
                'fear': None,
                'joy': None,
                'sadness': None,
                'dominant_emotion': None
            }
            
        # Parse successful response
        formatted_response = response.json()
        
        # Extract the primary emotion dictionary block
        # Watson structure: response -> emotionPredictions list -> index 0 -> emotion dict
        emotions = formatted_response['emotionPredictions'][0]['emotion']
        
        # Extract scores safely
        anger_score = emotions.get('anger', 0)
        disgust_score = emotions.get('disgust', 0)
        fear_score = emotions.get('fear', 0)
        joy_score = emotions.get('joy', 0)
        sadness_score = emotions.get('sadness', 0)
        
        # Determine the name of the dominant emotion
        dominant_emotion = max(emotions, key=emotions.get)
        
        # Construct exact target output dictionary format
        return {
            'anger': anger_score,
            'disgust': disgust_score,
            'fear': fear_score,
            'joy': joy_score,
            'sadness': sadness_score,
            'dominant_emotion': dominant_emotion
        }

    except (requests.exceptions.RequestException, KeyError, IndexError):
        # Fallback return structure for connection issues or malformed payloads
        return {
            'anger': None,
            'disgust': None,
            'fear': None,
            'joy': None,
            'sadness': None,
            'dominant_emotion': None
        }